from z3 import *
import argparse
import json
import sys

sys.path.insert(0, "../ChironCore/")
sys.path.insert(0, "../Submmission/")

from interfaces.sExecutionInterface import *
from ChironAST.builder import astGenPass
import z3solver as zs
from irhandler import *
from interpreter import *
import ast

# This is an example program showing the use
# of Z3 Solver in python.
def example(s):
    # To add symbolic variable x to solver
    s.addSymbVar("x")
    s.addSymbVar("y")
    # To add constraint in form of string
    s.addConstraint("x==5+y")
    s.addConstraint("And(x==y,x>5)")
    # s.addConstraint('Implies(x==4,y==x+8')
    # To access solvers directly use s.s.<function of z3>()
    print("constraints added till now", s.s.assertions())
    # To assign z=x+y
    s.addAssignment("z", "x+y")
    # To get any variable assigned
    print("variable assignment of z =", s.getVar("z"))

# IMPLEMENT THIS
# FEEL FREE TO MODIFIY THIS CODE.
def checkEq(args, ir):
    file1 = open("../Submission/testData.json", "r+")
    testData = json.loads(file1.read())
    file1.close()

    file2 = open("../Submission/testData1.json","r+")
    testData1=json.loads(file2.read())
    file2.close()

    solver = zs.z3Solver()
    solver1 = zs.z3Solver()

    testData = convertTestData(testData)
    testData1 = convertTestData(testData1)

    # to see what test data has been read.
    #print(testData)

    # This is the data read from the "-e" flag
    output = args.output

    # Iterate through entries and add constraints to the solver
    symbEnc_list = [data["symbEnc"] for data in testData.values()]
    symbEnc_list1 = [data["symbEnc"] for data in testData1.values()]

    params_list = [data["params"] for data in testData1.values()]

    constraints_list = [data["constraints"] for data in testData.values()]

    params = [value["params"] for key, value in testData.items()]
    input = [[f"{v}=={k}" for v, k in i.items()] for i in params]

    for info in symbEnc_list:
        for key in info:
            solver1.addSymbVar(key)

    final = []
    for index,i in enumerate(input):
        for index_2,const_set in enumerate(constraints_list):
            solver = zs.z3Solver()
            for key,value in params[index].items():
                solver.addSymbVar(key)
            for inp in i:
                solver.addConstraint(inp)
            # print(const_set[0])
            const_set_split = const_set[0].split(',')
            for const in const_set_split:
                solver.addConstraint(const)
            #print(solver.s.assertions())
            # Check whether solver is satisfiable or not
            if(str(solver.s.check())=="sat"):
                #print("satisfiable")
                enc1_equations = [f"{k},{v}" for k, v in symbEnc_list[index].items()]
                enc2_equations = [f"{k},{v}" for k, v in symbEnc_list1[index_2].items()]

                equations = []
                for eq1, eq2 in zip(enc1_equations, enc2_equations):
                    # Split each equation by ' == ' to separate LHS and RHS
                    lhs1, rhs1 = eq1.split(',')
                    lhs2, rhs2 = eq2.split(',')

                    # Check if the LHSs are the same
                    if lhs1 == lhs2:
                        # Equate the RHSs and append to the new list
                        equated_equation = f"{rhs1} == {rhs2}"
                        equations.append(equated_equation)
        final.append(equations)

    for key_value in final:
        for key in key_value:
            solver1.addConstraint(key)
    if(solver1.s.check() == sat):
        m = solver1.s.model()
        print(m)
    else:
        print("unsat")

if __name__ == "__main__":
    # you are free to add your own arguments and use them
    # in the functions of this file.
    cmdparser = argparse.ArgumentParser(
        description="symbSubmission for assignment Program Synthesis using Symbolic Execution"
    )
    cmdparser.add_argument("progfl")
    cmdparser.add_argument("-b", "--bin", action="store_true", help="load binary IR")
    cmdparser.add_argument(
        "-e",
        "--output",
        default=list(),
        type=ast.literal_eval,
        help="pass variables to Chiron program in python dictionary format",
    )
    # This object is use to store and pass the ir around.
    irHandler2 = IRHandler(None)
    args = cmdparser.parse_args()

    # generate IR of the program given
    # or load it from .kw file.
    if args.bin:
        ir = irHandler2.loadIR(args.progfl)
    else:
        parseTree = getParseTree(args.progfl)
        astgen = astGenPass()
        ir = astgen.visitStart(parseTree)

    irHandler2.pretty_print(irHandler2.ir)

    checkEq(args, ir)
    exit()
