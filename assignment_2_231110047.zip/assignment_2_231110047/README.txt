tests Directory:  assignment_2_23116059\Chiron-Framework-master\ChironCore\tests

tests:
e1p1.tl
e1p2.tl
e2p1.tl
e2p2.tl
e3p1.tl
e3p2.tl
e4p1.tl
e4p2.tl
e5p1.tl
e5p2.tl

where, the e{i}p{j}.tl program refers to {j}th program for {i}th example.

To run the tests, go to assignment_2_23116059\Chiron-Framework-master\ChironCore folder and type the following command in terminal:
python .\chiron.py -t 100 -se example/e{i}p1.tl -d "{':x': 5, ':y': 100}" -c "{':c1': 1, ':c2': 1}"
python .\chiron.py -t 100 -se example/e{i}p2.tl -d "{':x': 5, ':y': 100}" -c "{':c1': 1, ':c2': 1}"
where, {i} is the i'th example. It is necessary to execute these commands of same example for the program to work and not give wrong results or give error.
The above program will generate a new file names testData.json that must be renamed to testData1.json for first program and testData.json for second program.
In the end, run 
python ..\Submission\symbSubmission.py -b .\optimized.kw -e "['x','y']"
to get value of unknowns.
