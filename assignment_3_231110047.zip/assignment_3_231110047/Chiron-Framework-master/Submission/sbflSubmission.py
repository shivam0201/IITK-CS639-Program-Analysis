#!/usr/bin/env python3

import argparse
import math
import sys
import numpy as np

sys.path.insert(0, "../ChironCore/")
from irhandler import *
from ChironAST.builder import astGenPass
import csv


def fitnessScore(IndividualObject):
    """
    Parameters
    ----------
    IndividualObject : Individual (definition of this class is in ChironCore/sbfl.py)
        This is a object of class Individual. The Object has 3 elements
        1. IndividualObject.individual : activity matrix.
                                    type : list, row implies a test
                                    and element of rows are components.
        2. IndividualObject.fitness : fitness of activity matix.
                                    type : float
        3. Indivisual.fitness_valid : a flag used by Genetic Algorithm.
                                    type : boolean
    Returns
    -------
    fitness_score : flaot
        returns the fitness-score of the activity matrix.
        Note : No need to set/change fitness and fitness_valid attributes.
    """
    # Design the fitness function
    fitness_score = 0
    activity_mat = np.array(IndividualObject.individual, dtype="int")
    activity_mat = activity_mat[:, : activity_mat.shape[1] - 1]
    
    # Use 'activity_mat' to compute fitness of it.
    # ToDo : Write your code here to compute fitness of test-suite

    """
    Implementing DDU as a fitness function metric
    1. Density
    2. Diversity
    3. Uniqueness
    """
    #Density of the activity matrix
    total_components=len(activity_mat)
    mat_ones=sum(1 for row in activity_mat for element in row if element==1)
    total_rows=len(activity_mat)
    total_cols=len(activity_mat[0])
    density=mat_ones/(total_rows*total_cols)

    #Diversity of the activity matrix
    row_counts = {}

    for row in activity_mat:
        row_key = tuple(row)
        if row_key in row_counts:
            row_counts[row_key] += 1
        else:
            row_counts[row_key] = 1

    total_rows = len(activity_mat)

    if total_rows <= 1:
        return 1  # If there is only one or zero rows, diversity is 1

    # Calculate Gini-Simpson metric
    sum_squared_counts = sum(value * (value - 1) for value in row_counts.values())
    diversity = 1 - sum_squared_counts / (total_rows * (total_rows - 1))



    #Uniqueness of the activity matrix
    unique_rows, counts = np.unique(activity_mat, axis=0, return_counts=True)
    num_unique_rows = len(unique_rows)
    uniqueness=num_unique_rows/total_components

    p=1-np.abs(1-2*density)
    ddu=p*diversity*uniqueness
    fitness_score=ddu
    return -1*fitness_score


# This class takes a spectrum and generates ranks of each components.
# finish implementation of this class.
class SpectrumBugs:
    def __init__(self, spectrum):
        self.spectrum = np.array(spectrum, dtype="int")
        self.comps = self.spectrum.shape[1] - 1
        self.tests = self.spectrum.shape[0]
        self.activity_mat = self.spectrum[:, : self.comps]
        self.errorVec = self.spectrum[:, -1]

    def getActivity(self, comp_index):
        """
        get activity of component 'comp_index'
        Parameters
        ----------
        comp_index : int
        """
        return self.activity_mat[:, comp_index]

    def suspiciousness(self, comp_index):
        """
        Parameters
        ----------
        comp_index : int
            component number/index of which you want to compute how suspicious
            the component is. assumption: if a program has 3 components then
            they are denoted as c0,c1,c2 i.e 0,1,2
        Returns
        -------
        sus_score : float
            suspiciousness value/score of component 'comp_index'
        """
        sus_score = 0
        # ToDo : implement the suspiciousness score function.
        components=[]
        for row in self.activity_mat:
            components.append(row[comp_index])

        cf=0
        cp=0
        nf=0
        np=0
        for index,result in enumerate(self.errorVec):
            if result == 0:
                if components[index]==0:
                    cf=cf+1
                if components[index]==1:
                    cp=cp+1
            else:
                if components[index]==0:
                    nf=nf+1
                if components[index]==1:
                    np=np+1

        den=math.sqrt((cf+nf)*(cf+cp))
        if den>0:   
            sus_score=cf/den
        else:   
            sus_score=0
        
        return sus_score

    def getRankList(self):
        """
        find ranks of each components according to their suspeciousness score.

        Returns
        -------
        rankList : list
            ranList will contain data in this format:
                suppose c1,c2,c3,c4 are components and their ranks are
                1,2,3,4 then rankList will be :
                    [[c1,1],
                     [c2,2],-
                     [c3,3],
                     [c4,4]]
        """
        rankList = []
        unsorted_rankList={}
        cols=len(self.activity_mat[0])
        for i in range(cols):
            unsorted_rankList["c"+str(i+1)]=self.suspiciousness(i)
        
        # ToDo : implement rankList
        sorted_rankList = dict(sorted(unsorted_rankList.items(), key=lambda item: item[1], reverse=True))
        rankList_set=[[key,value] for key,value in sorted_rankList.items()]

        ranking = []
        rank=0
        prev=None
        for el in rankList_set:
            if el[1]!=prev:
                rank=rank+1
            ranking.append([el[0],rank])
            prev=el[1]
        rankList=ranking
        print(rankList)
        return rankList


# do not modify this function.
def computeRanks(spectrum, outfilename):
    """
    Parameters
    ----------
    spectrum : list
        spectrum
    outfilename : str
        components and their ranks.
    """
    S = SpectrumBugs(spectrum)
    rankList = S.getRankList()
    with open(outfilename, "w") as file:
        writer = csv.writer(file)
        writer.writerows(rankList)
