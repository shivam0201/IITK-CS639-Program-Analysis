tests Directory: assignment_3_231110047\Chiron-Framework-master\ChironCore\tests
output Directory: assignment_3_231110047\Chiron-Framework-master\ChironCore\tests\output

tests:
test1.tl
test1_buggy.tl
test2.tl
test2_buggy.tl
test3.tl
test3_buggy.tl
test4.tl
test4_buggy.tl
test5.tl
test5_buggy.tl

To run the tests, go to assignment_3_23116059\Chiron-Framework-master\ChironCore folder and type the following command in terminal:
python chiron.py --SBFL ./tests/test{i}.tl --buggy ./tests/test{i}_buggy.tl -vars "[':x', ':y', ':z']" --timeout 10 --ntests 20 --popsize 100 --cxpb 1.0 --mutpb 1.0 --ngen 100 --verbose True 
where {i} refers to the i'th testcase.