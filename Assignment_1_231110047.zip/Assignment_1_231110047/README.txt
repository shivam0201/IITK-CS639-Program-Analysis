tests Directory:  assignment_1_23116059\Chiron-Framework\KachuaCore\tests

testss:
fuzzing_example1.tl
fuzzing_example2.tl
fuzzing_example3.tl
fuzzing_example4.tl
fuzzing_example5.tl

Outputs Directory: assignment_1_23116059\Chiron-Framework\KachuaCore\Outputs

To run the tests, go to Assignment_1_23116047\Chiron-Framework\KachuaCore folder and type the following command in terminal:

python .\kachua.py -t 60 --fuzz .\tests\fuzzing_example1.tl -d "{':x':42,':y':20,':z':0}"
python .\kachua.py -t 60 --fuzz .\tests\fuzzing_example2.tl -d "{':x':52,':y':90,':z':-45}"
python .\kachua.py -t 60 --fuzz .\tests\fuzzing_example3.tl -d "{':x':21,':y':28,':z':98}"
python .\kachua.py -t 60 --fuzz .\tests\fuzzing_example4.tl -d "{':x':4,':y':29,':z':49}"
python .\kachua.py -t 60 --fuzz .\tests\fuzzing_example5.tl -d "{':x':5,':y':-95,':z':12}"