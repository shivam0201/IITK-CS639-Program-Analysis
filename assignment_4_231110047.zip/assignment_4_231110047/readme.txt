tests Directory: assignment_3_231110047\Chiron-Framework-master\ChironCore\tests
output Directory: assignment_3_231110047\Chiron-Framework-master\ChironCore\tests\output

tests:
test1.tl
test2.tl
test3.tl
test4.tl
test5.tl

To run the tests, go to assignment_4_23116059\Chiron-Framework-master\ChironCore folder and type the following command in terminal:
python chiron.py --control_flow -ai .\tests\test_{i}.tl
where {i} refers to the i'th test.